bl_info = {
    "name": "Sisir Importer",
    "author": "GitHub Copilot",
    "version": (1, 3, 0),
    "blender": (3, 0, 0),
    "location": "File > Import/Export > Sisir Guides (.ply); File > Import > Sisir Hair (.abc)",
    "description": "Import and export Sisir guides, and import Sisir Alembic hair with its groom attributes",
    "category": "Import-Export",
}

import math
import os
import re
import time

import bpy
from mathutils.geometry import interpolate_bezier
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ExportHelper, ImportHelper

from . import abc_reader


IMPORT_SCALE = 100.0


def _transform_point(point, import_scale=IMPORT_SCALE):
    x_coord, y_coord, z_coord = point
    # Sisir guide data matches the Maya-side orientation/scale expectations.
    # Blender needs the data scaled up and remapped from Y-up to Z-up.
    return (
        x_coord * import_scale,
        -z_coord * import_scale,
        y_coord * import_scale,
    )


def _parse_ply_header(handle):
    meta = {
        "format": "ascii",
        "vertex_count": 0,
        "vertex_props": [],
        "points_per_strand": None,
        "layers": [],
        "sisir_unit": None,
        "header_end": 0,
    }
    in_vertex_element = False

    while True:
        line = handle.readline()
        if not line:
            break
        decoded = line.decode("ascii", "ignore") if hasattr(line, "decode") else line
        stripped = decoded.strip()

        if stripped == "end_header":
            meta["header_end"] = handle.tell()
            break
        if stripped.startswith("format"):
            meta["format"] = stripped.split()[1]
        elif stripped.startswith("comment sisir_unit"):
            parts = stripped.split()
            if len(parts) >= 3:
                meta["sisir_unit"] = parts[2].lower()
        elif stripped.startswith("comment") and "points_per_strand" in stripped:
            try:
                meta["points_per_strand"] = int(stripped.split()[-1])
            except Exception:
                pass
        elif stripped.startswith("comment layer "):
            try:
                rest = stripped[len("comment layer ") :].strip()
                parts = rest.split(None, 1)
                layer_id = int(parts[0])
                layer_name = ""
                color = None
                visible = True
                if len(parts) > 1:
                    tail = parts[1].strip()
                    if tail.startswith('"'):
                        end = tail.find('"', 1)
                        if end > 0:
                            layer_name = tail[1:end]
                            tail = tail[end + 1 :].strip()
                    if tail:
                        numbers = tail.split()
                        if len(numbers) >= 3:
                            color = (float(numbers[0]), float(numbers[1]), float(numbers[2]))
                        if len(numbers) >= 4:
                            visible = int(numbers[3]) != 0
                meta["layers"].append(
                    {
                        "id": layer_id,
                        "name": layer_name,
                        "color": color,
                        "visible": visible,
                    }
                )
            except Exception:
                pass
        elif stripped.startswith("element vertex"):
            meta["vertex_count"] = int(stripped.split()[-1])
            in_vertex_element = True
        elif stripped.startswith("element"):
            in_vertex_element = False
        elif stripped.startswith("property") and in_vertex_element:
            parts = stripped.split()
            meta["vertex_props"].append(parts[2])

    return meta


def _read_ascii_vertices(handle, meta):
    props = meta["vertex_props"]
    try:
        ix = props.index("x")
        iy = props.index("y")
        iz = props.index("z")
    except ValueError as exc:
        raise RuntimeError("PLY file missing x/y/z properties") from exc

    anchor_idx = props.index("anchor") if "anchor" in props else None
    curve_id_idx = props.index("curve_id") if "curve_id" in props else None
    layer_id_idx = props.index("layer_id") if "layer_id" in props else None

    vertices = []
    for _ in range(meta["vertex_count"]):
        parts = handle.readline().strip().split()
        if len(parts) < 3:
            continue
        x = float(parts[ix])
        y = float(parts[iy])
        z = float(parts[iz])
        anchor = int(parts[anchor_idx]) if anchor_idx is not None else 0
        curve_id = int(parts[curve_id_idx]) if curve_id_idx is not None else 0
        layer_id = int(parts[layer_id_idx]) if layer_id_idx is not None else 0
        vertices.append((x, y, z, anchor, curve_id, layer_id))

    return vertices


def _read_ply_vertices(path):
    with open(path, "rb") as handle:
        meta = _parse_ply_header(handle)
        if meta["format"] != "ascii":
            raise RuntimeError("Only ASCII PLY exported by Sisir is supported")
        handle.seek(meta["header_end"])
        vertices = _read_ascii_vertices(handle, meta)
    return meta, vertices


def _sanitize_name(name, fallback):
    cleaned = bpy.path.clean_name(name or "")
    return cleaned if cleaned else fallback


def _unique_collection_name(base_name):
    if bpy.data.collections.get(base_name) is None:
        return base_name

    suffix = 1
    while True:
        candidate = f"{base_name}_{suffix:02d}"
        if bpy.data.collections.get(candidate) is None:
            return candidate
        suffix += 1


def _build_import_collections(path, layer_names, layer_visibility):
    file_stem = os.path.splitext(os.path.basename(path))[0] or "SisirGuides"
    root_name = _unique_collection_name(f"SisirGuides_{_sanitize_name(file_stem, 'Import')}")
    root_collection = bpy.data.collections.new(root_name)
    bpy.context.scene.collection.children.link(root_collection)
    root_collection["sisir_source_path"] = path

    layer_collections = {}
    for layer_id, layer_name in layer_names.items():
        collection_name = _sanitize_name(layer_name, f"Layer_{layer_id}")
        layer_collection = bpy.data.collections.new(collection_name)
        root_collection.children.link(layer_collection)
        layer_collection.hide_viewport = not layer_visibility.get(layer_id, True)
        layer_collection.hide_render = not layer_visibility.get(layer_id, True)
        layer_collection["sisir_layer_id"] = layer_id
        layer_collections[layer_id] = layer_collection

    return root_collection, layer_collections


def _group_strands(meta, vertices):
    has_curve_id = "curve_id" in (meta.get("vertex_props") or [])
    has_layer_id = "layer_id" in (meta.get("vertex_props") or [])

    if has_curve_id:
        strands = {}
        order = []
        for vertex in vertices:
            curve_id = vertex[4]
            layer_id = vertex[5] if has_layer_id else 0
            if curve_id not in strands:
                strands[curve_id] = {"layer_id": layer_id, "points": []}
                order.append(curve_id)
            strands[curve_id]["points"].append(vertex[:3])

        grouped = []
        for curve_id in order:
            strand = strands[curve_id]
            if len(strand["points"]) >= 2:
                grouped.append(
                    {
                        "curve_id": curve_id,
                        "layer_id": strand["layer_id"],
                        "points": strand["points"],
                    }
                )
        return grouped

    points_per_strand = meta.get("points_per_strand") or 2
    if points_per_strand < 2:
        points_per_strand = 2

    grouped = []
    for index in range(0, len(vertices), points_per_strand):
        chunk = vertices[index : index + points_per_strand]
        if len(chunk) < 2:
            continue
        grouped.append(
            {
                "curve_id": len(grouped),
                "layer_id": chunk[0][5] if has_layer_id else 0,
                "points": [vertex[:3] for vertex in chunk],
            }
        )
    return grouped


def _create_curve_object(name, strands, collection, bevel_depth=0.0, import_scale=IMPORT_SCALE):
    curve_data = bpy.data.curves.new(name=name, type="CURVE")
    curve_data.dimensions = "3D"
    curve_data.resolution_u = 1
    curve_data.bevel_depth = bevel_depth

    for strand in strands:
        points = strand["points"]
        spline = curve_data.splines.new(type="POLY")
        spline.points.add(len(points) - 1)
        for point_index, point in enumerate(points):
            transformed = _transform_point(point, import_scale)
            spline.points[point_index].co = (transformed[0], transformed[1], transformed[2], 1.0)
        spline.use_cyclic_u = False

    curve_object = bpy.data.objects.new(name, curve_data)
    curve_object["sisir_strand_count"] = len(strands)
    collection.objects.link(curve_object)
    return curve_object


def import_sisir_guides(path, bevel_depth=0.0, group_by_layer=True, report=None):
    start_time = time.time()
    meta, vertices = _read_ply_vertices(path)
    strands = _group_strands(meta, vertices)
    if not strands:
        raise RuntimeError("No valid guide strands found in the PLY file")

    # When sisir_unit is present the user chose the export unit to match their
    # Blender scene, so import positions as-is (scale=1.0).
    # Old files (no sisir_unit comment) fall back to legacy IMPORT_SCALE (100.0).
    import_scale = 1.0 if meta.get("sisir_unit") is not None else IMPORT_SCALE

    layer_meta = meta.get("layers") or []
    layer_names = {
        layer.get("id", 0): (layer.get("name") or f"Layer {layer.get('id', 0)}")
        for layer in layer_meta
    }
    layer_visibility = {
        layer.get("id", 0): layer.get("visible", True) for layer in layer_meta
    }

    for strand in strands:
        layer_id = strand["layer_id"]
        layer_names.setdefault(layer_id, f"Layer {layer_id}")
        layer_visibility.setdefault(layer_id, True)

    root_collection, layer_collections = _build_import_collections(path, layer_names, layer_visibility)

    created_objects = []
    if group_by_layer:
        strands_by_layer = {}
        for strand in strands:
            strands_by_layer.setdefault(strand["layer_id"], []).append(strand)

        for layer_id in sorted(strands_by_layer.keys()):
            layer_collection = layer_collections[layer_id]
            object_name = _sanitize_name(f"{layer_names[layer_id]}_Guides", f"Layer_{layer_id}_Guides")
            curve_object = _create_curve_object(
                object_name,
                strands_by_layer[layer_id],
                layer_collection,
                bevel_depth=bevel_depth,
                import_scale=import_scale,
            )
            color = next((layer.get("color") for layer in layer_meta if layer.get("id") == layer_id), None)
            if color:
                curve_object.color = (color[0], color[1], color[2], 1.0)
            created_objects.append(curve_object)
    else:
        object_name = _sanitize_name(os.path.splitext(os.path.basename(path))[0], "SisirGuides")
        curve_object = _create_curve_object(
            f"{object_name}_Guides",
            strands,
            root_collection,
            bevel_depth=bevel_depth,
            import_scale=import_scale,
        )
        created_objects.append(curve_object)

    for curve_object in created_objects:
        curve_object["sisir_source_path"] = path

    if created_objects:
        bpy.ops.object.select_all(action="DESELECT")
        for curve_object in created_objects:
            curve_object.select_set(True)
        bpy.context.view_layer.objects.active = created_objects[0]

    duration = time.time() - start_time
    message = f"Imported {len(strands)} Sisir guides in {duration:.2f}s"
    if report is not None:
        report({"INFO"}, message)
    else:
        print(message)

    return {
        "root_collection": root_collection,
        "objects": created_objects,
        "strand_count": len(strands),
    }


_OUTPUT_UNIT_METERS = {
    "MILLIMETERS": (0.001, "mm"),
    "CENTIMETERS": (0.01, "cm"),
    "METERS": (1.0, "m"),
}


def _safe_layer_name(name):
    return str(name).replace('"', "'").replace("\r", " ").replace("\n", " ")


def _format_ply_float(value):
    value = 0.0 if abs(value) < 5e-12 else value
    return format(value, ".9g")


def _legacy_spline_points(curve_object, spline):
    if spline.type == "BEZIER":
        bezier_points = spline.bezier_points
        if len(bezier_points) < 2:
            return []
        resolution = max(2, int(curve_object.data.resolution_u) + 1)
        sampled = []
        for index in range(len(bezier_points) - 1):
            current = bezier_points[index]
            following = bezier_points[index + 1]
            segment = interpolate_bezier(
                current.co,
                current.handle_right,
                following.handle_left,
                following.co,
                resolution,
            )
            sampled.extend(segment if index == 0 else segment[1:])
        return sampled

    return [point.co.to_3d() for point in spline.points]


def _legacy_curve_strands(curve_object):
    strands = []
    skipped_cyclic = 0
    for spline in curve_object.data.splines:
        if spline.use_cyclic_u:
            skipped_cyclic += 1
            continue
        points = _legacy_spline_points(curve_object, spline)
        if len(points) >= 2:
            strands.append(points)
    return strands, skipped_cyclic


def _hair_curve_strands(curve_object, depsgraph):
    evaluated_object = curve_object.evaluated_get(depsgraph)
    curve_data = evaluated_object.data
    cyclic_attribute = curve_data.attributes.get("cyclic")
    strands = []
    skipped_cyclic = 0
    for curve in curve_data.curves:
        is_cyclic = False
        if cyclic_attribute is not None and cyclic_attribute.domain == "CURVE":
            is_cyclic = bool(cyclic_attribute.data[curve.index].value)
        if is_cyclic:
            skipped_cyclic += 1
            continue
        points = [point.position.copy() for point in curve.points]
        if len(points) >= 2:
            strands.append(points)
    return strands, skipped_cyclic, evaluated_object.matrix_world.copy()


def _layer_for_object(curve_object, assigned_layers, used_ids):
    collection = curve_object.users_collection[0] if curve_object.users_collection else None
    key = collection.as_pointer() if collection is not None else -curve_object.as_pointer()
    if key in assigned_layers:
        return assigned_layers[key]

    preferred_id = None
    if collection is not None and "sisir_layer_id" in collection:
        try:
            preferred_id = int(collection["sisir_layer_id"])
        except (TypeError, ValueError):
            preferred_id = None
    if preferred_id is None or preferred_id < 0 or preferred_id in used_ids:
        preferred_id = 0
        while preferred_id in used_ids:
            preferred_id += 1
    used_ids.add(preferred_id)

    name = collection.name if collection is not None else curve_object.name
    visible = True
    if collection is not None:
        visible = not collection.hide_viewport and not collection.hide_render
    color = tuple(float(value) for value in curve_object.color[:3])
    layer = {
        "id": preferred_id,
        "name": _safe_layer_name(name),
        "color": color,
        "visible": visible,
    }
    assigned_layers[key] = layer
    return layer


def export_sisir_guides(
    context,
    path,
    selected_only=True,
    output_units="METERS",
    report=None,
):
    start_time = time.time()
    try:
        unit_meters, unit_label = _OUTPUT_UNIT_METERS[output_units]
    except KeyError as exc:
        raise ValueError(f"Unsupported output units: {output_units}") from exc

    candidates = context.selected_objects if selected_only else context.scene.objects
    curve_objects = [obj for obj in candidates if obj.type in {"CURVE", "CURVES"}]
    if not curve_objects:
        scope = "selected" if selected_only else "scene"
        raise RuntimeError(f"No {scope} Blender Curve or Hair Curves objects to export")

    scene_scale = float(context.scene.unit_settings.scale_length)
    if scene_scale <= 1e-8:
        scene_scale = 1.0
    coordinate_scale = scene_scale / unit_meters
    depsgraph = context.evaluated_depsgraph_get()

    layers_by_key = {}
    used_layer_ids = set()
    strands = []
    skipped_cyclic = 0
    skipped_invalid = 0
    for curve_object in curve_objects:
        layer = _layer_for_object(curve_object, layers_by_key, used_layer_ids)
        if curve_object.type == "CURVE":
            evaluated_object = curve_object.evaluated_get(depsgraph)
            object_strands, object_cyclic = _legacy_curve_strands(evaluated_object)
            matrix_world = evaluated_object.matrix_world.copy()
        else:
            object_strands, object_cyclic, matrix_world = _hair_curve_strands(
                curve_object, depsgraph
            )
        skipped_cyclic += object_cyclic

        for points in object_strands:
            converted = []
            valid = True
            for point in points:
                world = matrix_world @ point
                sisir_point = (
                    float(world.x) * coordinate_scale,
                    float(world.z) * coordinate_scale,
                    -float(world.y) * coordinate_scale,
                )
                if not all(math.isfinite(value) for value in sisir_point):
                    valid = False
                    break
                converted.append(sisir_point)
            if valid and len(converted) >= 2:
                strands.append({"layer_id": layer["id"], "points": converted})
            else:
                skipped_invalid += 1

    if not strands:
        raise RuntimeError("No valid open guide strands with at least two points were found")

    exported_layer_ids = {strand["layer_id"] for strand in strands}
    layers = sorted(
        (layer for layer in layers_by_key.values() if layer["id"] in exported_layer_ids),
        key=lambda item: item["id"],
    )
    vertex_count = sum(len(strand["points"]) for strand in strands)
    with open(path, "w", encoding="ascii", newline="\n") as handle:
        handle.write("ply\n")
        handle.write("format ascii 1.0\n")
        handle.write(f"comment sisir_unit {unit_label}\n")
        for layer in layers:
            red, green, blue = layer["color"]
            handle.write(
                f'comment layer {layer["id"]} "{layer["name"]}" '
                f"{_format_ply_float(red)} {_format_ply_float(green)} "
                f"{_format_ply_float(blue)} {1 if layer['visible'] else 0}\n"
            )
        handle.write(f"element vertex {vertex_count}\n")
        handle.write("property float x\n")
        handle.write("property float y\n")
        handle.write("property float z\n")
        handle.write("property uchar anchor\n")
        handle.write("property int layer_id\n")
        handle.write("property int curve_id\n")
        handle.write("end_header\n")
        for curve_id, strand in enumerate(strands):
            for point_index, point in enumerate(strand["points"]):
                handle.write(
                    f"{_format_ply_float(point[0])} {_format_ply_float(point[1])} "
                    f"{_format_ply_float(point[2])} {1 if point_index == 0 else 0} "
                    f"{strand['layer_id']} {curve_id}\n"
                )

    duration = time.time() - start_time
    message = f"Exported {len(strands)} Sisir guides ({vertex_count} points) in {duration:.2f}s"
    if report is not None:
        report({"INFO"}, message)
        if skipped_cyclic:
            report({"WARNING"}, f"Skipped {skipped_cyclic} cyclic splines")
        if skipped_invalid:
            report({"WARNING"}, f"Skipped {skipped_invalid} strands with invalid points")
    else:
        print(message)
    return {
        "strand_count": len(strands),
        "point_count": vertex_count,
        "layer_count": len(layers),
        "skipped_cyclic": skipped_cyclic,
        "skipped_invalid": skipped_invalid,
    }

def _get_or_create_hair_material(shader_mode):
    material_tag = f"sisir_hair_{shader_mode.lower()}"
    for material in bpy.data.materials:
        if material.get("sisir_hair_material") == material_tag:
            return material

    display_name = "Sisir Hair (Cycles)" if shader_mode == "CYCLES" else "Sisir Hair (Eevee)"
    material = bpy.data.materials.new(name=display_name)
    material["sisir_hair_material"] = material_tag
    material.use_nodes = True
    material.diffuse_color = (0.12, 0.045, 0.02, 1.0)

    node_tree = material.node_tree
    node_tree.nodes.clear()
    output = node_tree.nodes.new("ShaderNodeOutputMaterial")
    output.location = (320.0, 0.0)

    if shader_mode == "CYCLES":
        shader = node_tree.nodes.new("ShaderNodeBsdfHairPrincipled")
    else:
        shader = node_tree.nodes.new("ShaderNodeBsdfPrincipled")
        base_color = shader.inputs.get("Base Color")
        if base_color is not None:
            base_color.default_value = material.diffuse_color
        roughness = shader.inputs.get("Roughness")
        if roughness is not None:
            roughness.default_value = 0.45

    shader.location = (0.0, 0.0)
    node_tree.links.new(shader.outputs[0], output.inputs["Surface"])
    return material


# Blender domain and type for each groom attribute, mirroring the Alembic scopes
# Sisir writes: uniform params are per curve, vertex params are per control point.
# Anything read at an unexpected scope is skipped rather than guessed at.
_GROOM_ATTRIBUTE_SPECS = {
    "groom_root_uv": ("CURVE", "FLOAT2", "vector", 2),
    "groom_clumpid": ("CURVE", "INT", "value", 1),
    "groom_color": ("POINT", "FLOAT_COLOR", "color", 3),
    "groom_roughness": ("POINT", "FLOAT", "value", 1),
    "groom_ao": ("POINT", "FLOAT", "value", 1),
}

_EXPECTED_SCOPE = {"CURVE": abc_reader.SCOPE_UNIFORM, "POINT": abc_reader.SCOPE_VERTEX}

# Blender appends .001, .002 ... when an imported name collides with an existing object.
_NAME_SUFFIX = re.compile(r"[.][0-9]{3}$")


def _base_object_name(name):
    return _NAME_SUFFIX.sub("", name)


def _apply_groom_attributes(curve_object, attributes, warnings):
    """Write one object's groom attributes onto its Curves data.

    Returns the names actually written. Each is length-checked against the domain it
    claims: a misaligned array would be invisible in the spreadsheet but wrong, so a
    mismatch drops that attribute instead of writing it.
    """
    import numpy as np

    data = curve_object.data
    domain_sizes = {"CURVE": len(data.curves), "POINT": len(data.points)}
    written = []

    for name, attribute in sorted(attributes.items()):
        spec = _GROOM_ATTRIBUTE_SPECS.get(name)
        if spec is None:
            continue
        domain, data_type, field, extent = spec

        if attribute.scope != _EXPECTED_SCOPE[domain]:
            warnings.append("%s: %s has scope '%s', expected '%s'; skipped" % (
                curve_object.name, name, attribute.scope, _EXPECTED_SCOPE[domain]))
            continue
        if attribute.extent != extent:
            warnings.append("%s: %s has %d components, expected %d; skipped" % (
                curve_object.name, name, attribute.extent, extent))
            continue
        expected = domain_sizes[domain]
        if attribute.count != expected:
            warnings.append("%s: %s has %d entries, expected %d; skipped" % (
                curve_object.name, name, attribute.count, expected))
            continue
        if expected == 0:
            continue

        values = attribute.values
        if data_type == "FLOAT_COLOR":
            # Alembic carries RGB, Blender's colour attribute is RGBA.
            rgba = np.ones((expected, 4), dtype=np.float32)
            rgba[:, :3] = values.reshape(expected, 3)
            values = rgba.reshape(-1)
        elif data_type == "INT":
            values = values.astype(np.int32, copy=False)
        else:
            values = values.astype(np.float32, copy=False)

        existing = data.attributes.get(name)
        if existing is not None:
            data.attributes.remove(existing)
        attr = data.attributes.new(name=name, type=data_type, domain=domain)
        attr.data.foreach_set(field, values)
        written.append(name)

    return written


def _radius_attribute(curve_object):
    if curve_object.type != "CURVES":
        return None
    radius = curve_object.data.attributes.get("radius")
    if radius is None or radius.data_type != "FLOAT" or radius.domain != "POINT":
        return None
    return radius


def _scale_radius_attribute(radius, thickness_scale):
    if abs(thickness_scale - 1.0) <= 1e-8:
        return
    values = [0.0] * len(radius.data)
    radius.data.foreach_get("value", values)
    values = [max(0.0, value * thickness_scale) for value in values]
    radius.data.foreach_set("value", values)


def import_sisir_hair_alembic(
    context,
    path,
    import_scale=1.0,
    thickness_scale=1.0,
    assign_material=True,
    shader_mode="AUTO",
    set_frame_range=True,
    always_add_cache_reader=False,
    import_attributes=True,
    report=None,
):
    if not hasattr(bpy.ops.wm, "alembic_import"):
        raise RuntimeError("This Blender build does not provide the native Alembic importer")

    start_time = time.time()
    existing_objects = {obj.as_pointer() for obj in bpy.data.objects}
    result = bpy.ops.wm.alembic_import(
        filepath=path,
        relative_path=False,
        scale=import_scale,
        set_frame_range=set_frame_range,
        validate_meshes=False,
        always_add_cache_reader=always_add_cache_reader,
        is_sequence=False,
        as_background_job=False,
    )
    if "FINISHED" not in result:
        raise RuntimeError("Blender's native Alembic importer did not finish")

    imported_objects = [obj for obj in bpy.data.objects if obj.as_pointer() not in existing_objects]
    curve_objects = [obj for obj in imported_objects if obj.type == "CURVES"]
    if not curve_objects:
        raise RuntimeError("The Alembic file did not create any Blender Curves objects")

    resolved_shader_mode = shader_mode
    if resolved_shader_mode == "AUTO":
        resolved_shader_mode = "CYCLES" if context.scene.render.engine == "CYCLES" else "EEVEE"
    hair_material = _get_or_create_hair_material(resolved_shader_mode) if assign_material else None

    radius_object_count = 0
    missing_radius = []
    strand_count = 0
    point_count = 0
    for curve_object in curve_objects:
        radius = _radius_attribute(curve_object)
        if radius is None:
            missing_radius.append(curve_object.name)
        else:
            _scale_radius_attribute(radius, thickness_scale)
            radius_object_count += 1

        if hair_material is not None and hair_material.name not in curve_object.data.materials:
            curve_object.data.materials.append(hair_material)

        curve_object["sisir_source_path"] = path
        curve_object["sisir_thickness_scale"] = thickness_scale
        curve_object["sisir_has_radius"] = radius is not None
        strand_count += len(curve_object.data.curves)
        point_count += len(curve_object.data.points)

    # Blender's Alembic reader takes only P, nVertices and widths from a curves
    # archive and drops every arbGeomParam, so Sisir's groom attributes are read
    # straight out of the file here. A parse failure must never cost the user their
    # import: the curves are already in the scene and correct without this.
    attribute_names = []
    attribute_warnings = []
    if import_attributes:
        try:
            archive = abc_reader.read_groom_attributes(path)
        except Exception as exc:
            archive = {}
            attribute_warnings.append("could not read Sisir attributes: %s" % exc)

        if archive:
            by_base_name = {}
            for curve_object in curve_objects:
                by_base_name.setdefault(_base_object_name(curve_object.name), []).append(curve_object)
            written = set()
            for object_name, attributes in archive.items():
                candidates = by_base_name.get(object_name)
                if not candidates:
                    attribute_warnings.append(
                        "no imported object matches archive object '%s'" % object_name)
                    continue
                # pop so two archive objects sharing a base name each get their own.
                target = candidates.pop(0)
                written.update(_apply_groom_attributes(target, attributes, attribute_warnings))
            attribute_names = sorted(written)

    bpy.ops.object.select_all(action="DESELECT")
    for curve_object in curve_objects:
        curve_object.select_set(True)
    context.view_layer.objects.active = curve_objects[0]

    duration = time.time() - start_time
    if not import_attributes:
        attribute_summary = "attributes skipped"
    elif attribute_names:
        attribute_summary = "attributes: " + ", ".join(attribute_names)
    else:
        attribute_summary = "no Sisir attributes found"
    message = (
        f"Imported {strand_count} hair curves ({point_count} points) from Alembic; "
        f"radius found on {radius_object_count}/{len(curve_objects)} objects; "
        f"{attribute_summary}; in {duration:.2f}s"
    )
    if report is not None:
        report({"WARNING" if missing_radius or attribute_warnings else "INFO"}, message)
        if missing_radius:
            report({"WARNING"}, "Missing point radius on: " + ", ".join(missing_radius))
        for warning in attribute_warnings:
            report({"WARNING"}, warning)
    else:
        print(message)
        for warning in attribute_warnings:
            print("WARNING:", warning)

    return {
        "objects": curve_objects,
        "strand_count": strand_count,
        "point_count": point_count,
        "radius_object_count": radius_object_count,
        "attribute_names": attribute_names,
        "attribute_warnings": attribute_warnings,
    }

class SISIR_OT_export_guides(Operator, ExportHelper):
    bl_idname = "sisir.export_guides"
    bl_label = "Export Sisir Guides"
    bl_description = "Export Blender curves using Sisir's guide-compatible ASCII PLY schema"
    bl_options = {"REGISTER"}

    filename_ext = ".ply"
    filter_glob: StringProperty(default="*.ply", options={"HIDDEN"})
    selected_only: BoolProperty(
        name="Selected Objects Only",
        description="Export only selected Curve and Hair Curves objects",
        default=True,
    )
    output_units: EnumProperty(
        name="Output Units",
        description="Coordinate units written to the PLY; select the same units when importing in Sisir",
        items=(
            ("MILLIMETERS", "Millimeters", "Write coordinates in millimeters"),
            ("CENTIMETERS", "Centimeters", "Write coordinates in centimeters"),
            ("METERS", "Meters", "Write coordinates in meters"),
        ),
        default="METERS",
    )

    def execute(self, context):
        try:
            export_sisir_guides(
                context,
                self.filepath,
                selected_only=self.selected_only,
                output_units=self.output_units,
                report=self.report,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}

class SISIR_OT_import_guides(Operator, ImportHelper):
    bl_idname = "sisir.import_guides"
    bl_label = "Import Sisir Guides"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".ply"
    filter_glob: StringProperty(default="*.ply", options={"HIDDEN"})
    group_by_layer: BoolProperty(
        name="Group by Layer",
        description="Create one Blender curve object per Sisir layer",
        default=True,
    )
    bevel_depth: FloatProperty(
        name="Bevel Depth",
        description="Optional curve thickness for the imported guides",
        default=0.0,
        min=0.0,
        soft_max=0.01,
        precision=4,
    )

    def execute(self, context):
        del context
        try:
            import_sisir_guides(
                self.filepath,
                bevel_depth=self.bevel_depth,
                group_by_layer=self.group_by_layer,
                report=self.report,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}


class SISIR_OT_import_hair_alembic(Operator, ImportHelper):
    bl_idname = "sisir.import_hair_alembic"
    bl_label = "Import Sisir Hair Alembic"
    bl_description = ("Import Alembic with Blender, preserve its radius attribute, read Sisir's "
                      "groom attributes, and set up hair shading")
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".abc"
    filter_glob: StringProperty(default="*.abc", options={"HIDDEN"})
    import_scale: FloatProperty(
        name="Import Scale",
        description="Scale applied by Blender's native Alembic importer",
        default=1.0,
        min=0.000001,
        soft_min=0.01,
        soft_max=100.0,
    )
    thickness_scale: FloatProperty(
        name="Thickness Scale",
        description="Multiplier applied to the imported point-domain radius attribute",
        default=1.0,
        min=0.0,
        soft_max=10.0,
        precision=4,
    )
    assign_material: BoolProperty(
        name="Assign Hair Material",
        description="Assign a reusable material so native hair curves are visible in rendered shading",
        default=True,
    )
    shader_mode: EnumProperty(
        name="Material Type",
        description="Shader used by the generated Sisir hair material",
        items=(
            ("AUTO", "Automatic", "Use Principled Hair in Cycles and Principled BSDF otherwise"),
            ("CYCLES", "Cycles Hair", "Use the Cycles Principled Hair BSDF"),
            ("EEVEE", "Eevee Compatible", "Use a Principled BSDF material"),
        ),
        default="AUTO",
    )
    set_frame_range: BoolProperty(
        name="Set Frame Range",
        description="Update the scene frame range from the Alembic archive",
        default=True,
    )
    always_add_cache_reader: BoolProperty(
        name="Always Add Cache Reader",
        description="Add an Alembic cache modifier even when the archive has one sample",
        default=False,
    )
    import_attributes: BoolProperty(
        name="Import Sisir Attributes",
        description=("Read Sisir's groom attributes (root UV, clump ID, color, roughness, AO) "
                     "from the archive and add them to the curves. Blender's own Alembic reader "
                     "does not import these"),
        default=True,
    )

    def execute(self, context):
        try:
            import_sisir_hair_alembic(
                context,
                self.filepath,
                import_scale=self.import_scale,
                thickness_scale=self.thickness_scale,
                assign_material=self.assign_material,
                shader_mode=self.shader_mode,
                set_frame_range=self.set_frame_range,
                always_add_cache_reader=self.always_add_cache_reader,
                import_attributes=self.import_attributes,
                report=self.report,
            )
        except Exception as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}

def menu_func_import(self, context):
    del context
    self.layout.operator(SISIR_OT_import_guides.bl_idname, text="Sisir Guides (.ply)")
    self.layout.operator(SISIR_OT_import_hair_alembic.bl_idname, text="Sisir Hair (.abc)")


def menu_func_export(self, context):
    del context
    self.layout.operator(SISIR_OT_export_guides.bl_idname, text="Sisir Guides (.ply)")


classes = (
    SISIR_OT_export_guides,
    SISIR_OT_import_guides,
    SISIR_OT_import_hair_alembic,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    try:
        unregister()
    except Exception:
        pass
    register()
    bpy.ops.sisir.import_guides("INVOKE_DEFAULT")
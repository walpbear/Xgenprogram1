"""Minimal read-only Alembic (Ogawa) reader for Sisir's groom attributes.

Blender's native Alembic importer reads only P, nVertices and widths from a curves
archive; every .arbGeomParams entry is dropped, and Blender ships no Alembic Python
bindings. So the groom attributes Sisir writes -- groom_root_uv, groom_clumpid,
groom_color, groom_roughness, groom_ao -- have to be read out of the file directly.

This parses just enough of the format to reach those arrays: the Ogawa container, the
object hierarchy, and the property headers of each curves object's .arbGeomParams
compound. Positions, radius and curve topology still come from Blender's importer.
Nothing here writes, and nothing here imports bpy, so it can be exercised standalone.

The layout follows Alembic's own reader (lib/Alembic/AbcCoreOgawa/ReadUtil.cpp,
ReadObjectHeaders / ReadPropertyHeaders / ReadIndexedMetaData, and Ogawa/IData.cpp).
The bit masks below are transcribed from ReadPropertyHeaders' comment block rather
than rederived.
"""

import struct

try:
    import numpy as np
except ImportError:  # pragma: no cover - Blender always ships numpy
    np = None


GROOM_ATTRIBUTES = (
    "groom_root_uv",
    "groom_clumpid",
    "groom_color",
    "groom_roughness",
    "groom_ao",
)

# Scope tokens Alembic writes into a geom param's metadata (geoScope=...).
SCOPE_CONSTANT = "con"
SCOPE_UNIFORM = "uni"      # one value per curve
SCOPE_VARYING = "var"
SCOPE_VERTEX = "vtx"       # one value per control point
SCOPE_FACEVARYING = "fvr"

_MAGIC = b"Ogawa"
_DATA_BIT = 0x8000000000000000
_POS_MASK = 0x7FFFFFFFFFFFFFFF

# Alembic PlainOldDataType -> numpy dtype. Strings are deliberately unsupported:
# none of the groom attributes use them, and they need a separate decode path.
_POD_DTYPES = {
    0: "|u1",   # bool
    1: "<u1",
    2: "<i1",
    3: "<u2",
    4: "<i2",
    5: "<u4",
    6: "<i4",
    7: "<u8",
    8: "<i8",
    9: "<f2",
    10: "<f4",
    11: "<f8",
}

_ARRAY_SAMPLE_KEY_BYTES = 16  # each array sample begins with a digest


class SisirAbcError(Exception):
    """The archive is not something this reader understands."""


class GroomAttribute(object):
    """One arbGeomParam sample, as a flat numpy array.

    `values` holds extent * count scalars; `extent` is the component count (2 for a
    root UV, 3 for a colour, 1 otherwise) so the caller can reshape without
    re-deriving it from the length.
    """

    __slots__ = ("name", "values", "scope", "extent")

    def __init__(self, name, values, scope, extent):
        self.name = name
        self.values = values
        self.scope = scope
        self.extent = extent

    @property
    def count(self):
        return len(self.values) // self.extent if self.extent else 0

    def __repr__(self):
        return "GroomAttribute(%r, scope=%s, extent=%d, count=%d)" % (
            self.name, self.scope, self.extent, self.count)


class _PropertyHeader(object):
    __slots__ = ("name", "ptype", "pod", "extent", "num_samples", "metadata")

    def __init__(self, name, ptype, pod, extent, num_samples, metadata):
        self.name = name
        self.ptype = ptype  # 0 compound, 1 scalar, 2 array
        self.pod = pod
        self.extent = extent
        self.num_samples = num_samples
        self.metadata = metadata

    @property
    def scope(self):
        for token in self.metadata.split(";"):
            if token.startswith("geoScope="):
                return token[len("geoScope="):]
        return ""


class _Reader(object):
    """Walks the Ogawa container. All offsets are absolute file positions."""

    def __init__(self, handle):
        self._f = handle

    # -- container primitives ------------------------------------------------

    def group_children(self, offset):
        self._f.seek(offset)
        raw = self._f.read(8)
        if len(raw) != 8:
            raise SisirAbcError("truncated group header")
        count = struct.unpack("<Q", raw)[0]
        if count > 0xFFFFFF:
            raise SisirAbcError("implausible group child count: %d" % count)
        if count == 0:
            return ()
        raw = self._f.read(8 * count)
        if len(raw) != 8 * count:
            raise SisirAbcError("truncated group child table")
        return struct.unpack("<%dQ" % count, raw)

    @staticmethod
    def is_data(pointer):
        return bool(pointer & _DATA_BIT)

    @staticmethod
    def is_empty(pointer):
        # A group pointer of 0, or a data pointer whose position masks to 0, is the
        # empty child. Reading at offset 0 would otherwise hand back the file header.
        return (pointer & _POS_MASK) == 0

    def data_bytes(self, pointer):
        if self.is_empty(pointer):
            return b""
        self._f.seek(pointer & _POS_MASK)
        raw = self._f.read(8)
        if len(raw) != 8:
            raise SisirAbcError("truncated data header")
        size = struct.unpack("<Q", raw)[0]
        payload = self._f.read(size)
        if len(payload) != size:
            raise SisirAbcError("truncated data payload (wanted %d)" % size)
        return payload

    # -- Alembic structures --------------------------------------------------

    def indexed_metadata(self, pointer):
        """Alembic prepends an empty entry, so header indices are 1-based here."""
        blob = self.data_bytes(pointer)
        table = [""]
        pos = 0
        while pos < len(blob):
            size = blob[pos]
            pos += 1
            if pos + size > len(blob):
                raise SisirAbcError("truncated indexed metadata")
            table.append(blob[pos:pos + size].decode("utf-8", "replace"))
            pos += size
        return table

    def object_header_names(self, pointer):
        blob = self.data_bytes(pointer)
        if len(blob) <= 32:
            return []
        blob = blob[:-32]  # trailing hashes
        names = []
        pos = 0
        while pos < len(blob):
            if pos + 4 > len(blob):
                raise SisirAbcError("truncated object header")
            size = struct.unpack_from("<I", blob, pos)[0]
            pos += 4
            if size == 0 or pos + size + 1 > len(blob):
                raise SisirAbcError("bad object header name")
            names.append(blob[pos:pos + size].decode("utf-8", "replace"))
            pos += size
            meta_index = blob[pos]
            pos += 1
            if meta_index == 0xFF:
                meta_size = struct.unpack_from("<I", blob, pos)[0]
                pos += 4 + meta_size
        return names

    def property_headers(self, pointer, metadata_table):
        blob = self.data_bytes(pointer)
        headers = []
        pos = 0
        size = len(blob)
        while pos < size:
            if pos + 4 > size:
                raise SisirAbcError("truncated property header")
            info = struct.unpack_from("<I", blob, pos)[0]
            pos += 4

            ptype = info & 0x0003
            size_hint = (info & 0x000C) >> 2

            def take_hinted(position):
                # numSamples / first / last / nameSize / metaSize all use the hint.
                if size_hint == 0:
                    return blob[position], position + 1
                if size_hint == 1:
                    return struct.unpack_from("<H", blob, position)[0], position + 2
                return struct.unpack_from("<I", blob, position)[0], position + 4

            pod = 0
            extent = 0
            num_samples = 0
            if ptype != 0:
                pod = (info & 0x00F0) >> 4
                extent = (info & 0xFF000) >> 12
                num_samples, pos = take_hinted(pos)
                if info & 0x0200:
                    _first, pos = take_hinted(pos)
                    _last, pos = take_hinted(pos)
                if info & 0x0100:
                    _tsidx, pos = take_hinted(pos)

            name_size, pos = take_hinted(pos)
            if name_size == 0 or pos + name_size > size:
                raise SisirAbcError("bad property header name")
            name = blob[pos:pos + name_size].decode("utf-8", "replace")
            pos += name_size

            meta_index = (info & 0xFF00000) >> 20
            if meta_index == 0xFF:
                meta_size, pos = take_hinted(pos)
                metadata = blob[pos:pos + meta_size].decode("utf-8", "replace")
                pos += meta_size
            elif meta_index < len(metadata_table):
                metadata = metadata_table[meta_index]
            else:
                raise SisirAbcError("property metadata index %d out of range" % meta_index)

            headers.append(_PropertyHeader(name, ptype, pod, extent, num_samples, metadata))
        return headers

    def array_sample(self, group_pointer, header):
        """Sample 0 of an array property, as a flat numpy array."""
        dtype = _POD_DTYPES.get(header.pod)
        if dtype is None:
            raise SisirAbcError("unsupported POD %d on %s" % (header.pod, header.name))
        children = self.group_children(group_pointer)
        if not children:
            return None
        payload = self.data_bytes(children[0])
        if len(payload) < _ARRAY_SAMPLE_KEY_BYTES:
            return None
        return np.frombuffer(payload, dtype=dtype, offset=_ARRAY_SAMPLE_KEY_BYTES)


def _compound_children(reader, group_pointer, metadata_table):
    """Sub-property pointers paired with their headers, in declaration order.

    A compound's group holds its sub-properties followed by one data child carrying
    all their headers, so the two lists line up index for index.
    """
    children = reader.group_children(group_pointer)
    if not children:
        return []
    headers = reader.property_headers(children[-1], metadata_table)
    return list(zip(children[:-1], headers))


def _find_compound(reader, group_pointer, metadata_table, name):
    for pointer, header in _compound_children(reader, group_pointer, metadata_table):
        if header.name == name and header.ptype == 0:
            return pointer
    return None


def read_groom_attributes(path, names=GROOM_ATTRIBUTES):
    """Read Sisir's groom arbGeomParams out of an Alembic file.

    Returns {object_name: {attribute_name: GroomAttribute}}. Objects without any of
    the requested attributes are omitted. Raises SisirAbcError if the archive is not
    readable as Ogawa; callers should treat that as "no attributes" rather than as a
    failed import.
    """
    if np is None:
        raise SisirAbcError("numpy is required to read Alembic attributes")

    wanted = set(names)
    result = {}

    with open(path, "rb") as handle:
        header = handle.read(16)
        if len(header) != 16 or header[:5] != _MAGIC:
            raise SisirAbcError("not an Ogawa Alembic archive")
        root_offset = struct.unpack("<Q", header[8:16])[0]

        reader = _Reader(handle)
        root = reader.group_children(root_offset)
        if len(root) < 6:
            raise SisirAbcError("unexpected archive root (%d children)" % len(root))

        metadata_table = reader.indexed_metadata(root[5])

        # Top object group: [0] its own properties, [1..n-2] child objects,
        # [n-1] the child object headers.
        top = reader.group_children(root[2])
        if len(top) < 2:
            return result
        object_names = reader.object_header_names(top[-1])
        object_groups = top[1:-1]

        for index, group_pointer in enumerate(object_groups):
            if index >= len(object_names):
                break
            name = object_names[index]
            if reader.is_empty(group_pointer) or reader.is_data(group_pointer):
                continue

            object_children = reader.group_children(group_pointer)
            if not object_children:
                continue
            properties = object_children[0]
            if reader.is_empty(properties):
                continue

            geom = _find_compound(reader, properties, metadata_table, ".geom")
            if geom is None:
                continue
            arb = _find_compound(reader, geom, metadata_table, ".arbGeomParams")
            if arb is None:
                continue

            found = {}
            for pointer, prop in _compound_children(reader, arb, metadata_table):
                if prop.name not in wanted or prop.ptype != 2:
                    continue
                if reader.is_empty(pointer) or reader.is_data(pointer):
                    continue
                # Sisir writes a single time sample; anything extra is ignored.
                values = reader.array_sample(pointer, prop)
                if values is None:
                    continue
                found[prop.name] = GroomAttribute(
                    prop.name, values, prop.scope, max(1, prop.extent))
            if found:
                result[name] = found

    return result

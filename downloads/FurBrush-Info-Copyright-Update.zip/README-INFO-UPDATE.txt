FurBrush Info text update

Save your scene and close FurBrush. Replace FurBrush.exe in your existing installation with the executable in this ZIP, then reopen and select Info > About.

The Info version label now reads:
FurBrush v1.2.202610111652
Copyright (copyright symbol) 2026 Taron Sohn

The previous "Based on Sisir" line is removed from this label. Original bundled license and third-party attribution remain intact. The displayed customization does not modify those license terms.

Window panel toggles, Viewport recovery, saved-color loader, app/dialog icon changes and splash compatibility are retained. Your saved themes and settings are not included or overwritten.

Validated the exact UTF-8 copyright string referenced by the executable, PE structure, and all 74 helper emulator cases. This text-only change has not been visually tested in the full Windows app.

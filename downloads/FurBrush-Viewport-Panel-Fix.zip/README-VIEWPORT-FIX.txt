FurBrush Viewport / HDR-lighting panel recovery

1. Save your scene, then close FurBrush.
2. Extract FurBrush.exe into your existing installation folder, replacing the previous FurBrush.exe. Keep original Sisir.exe as backup.
3. Open FurBrush.exe, stay in Render, and choose View > Viewport. If Viewport is already checked, uncheck it and check it again.
4. View > Default Layout now also explicitly shows and raises the Viewport settings dock.

This update adds the dock's own standard Qt toggle action to View. It does not recreate render controls, change renderer settings, delete saved layouts, reset your colors, or edit scene data. The existing application builds the HDR/background/light controls inside this dock. The package contains no saved-theme files.

Validation: Ghidra located the Viewport dock and its control builder. Qt reproduced the issue of a hidden dock staying hidden after re-docking, and verified that its toggle action or show/raise restores it. 16 emulated dock-helper cases passed; the existing 20 saved-theme-loader and 14 title/Help-helper cases also passed. The actual Windows application and its Render panel have not been run here; confirm on your machine.

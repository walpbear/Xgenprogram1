The included font is Geist Pixel, supplied by you, under the included OFL license.

To use it, double-click GeistPixel-Regular-VariableFont_ELSH.ttf in Windows and choose Install. Restart FurBrush after installing.

The retro theme selects Geist Pixel at 10pt. If it is not installed, Qt uses a system fallback. You can change the font-family line in themes/Windows7-Retro.qss to "Segoe UI" for more authentic Windows 7 typography, or increase font-size for readability.

This package does not install fonts automatically or edit Windows font settings.

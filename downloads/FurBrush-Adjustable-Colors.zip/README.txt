ADJUSTABLE UI COLORS

Run Customize-Colors.bat to open the Windows color editor. Choose a preset or use Choose... / #RRGGBB values for six colors. Save colors, then close and restart FurBrush through Start-FurBrush.bat or Start-FurBrush-Retro.bat.

The preview changes immediately in the editor. FurBrush itself needs a restart; the editor does not close the app or discard open scenes. Settings are saved to themes/colors.json. Every save keeps a unique backup of the previous QSS in themes/backups. Choosing Retro Blue and saving restores the default palette.

When upgrading from an earlier package, copy your existing themes folder elsewhere before replacing files. The color editor renders themes/Windows7-Retro.template.qss into themes/Windows7-Retro.qss; manual changes to the latter are backed up but replaced on Save. Make persistent custom styling changes in the template instead.

The Windows editor UI has not been run here. PowerShell syntax and palette/save/backup logic were executed in PowerShell 7 on Linux; four generated palettes were rendered and checked in Qt. Windows PowerShell 5.1/WPF/WinForms runtime testing is still needed.

FurBrush - experimental Windows 7 retro theme

INSTALL
1. Close all Sisir/FurBrush windows and old launchers.
2. Extract ALL files into your COMPLETE original Sisir installation, next to the untouched Sisir.exe and all DLLs. Replace the older FurBrush files.
3. Optional font: open fonts/GeistPixel-Regular-VariableFont_ELSH.ttf and choose Install. Restart the app afterwards. If not installed, a system fallback is used.
4. Run Start-FurBrush.bat for the artwork splash plus retro theme, or Start-FurBrush-Retro.bat to skip the splash.

EDIT THE UI THEME
Edit themes/Windows7-Retro.qss with Notepad, save, then restart through either launcher. Its font-family and font-size are near the top. Use "Segoe UI" instead of "Geist Pixel" for more authentic Windows 7 lettering. Keep the small arrow/check PNGs in the themes folder.

This styles Qt widgets with pale blue panels, glossy beveled buttons, classic menus, blue selections and a green progress bar. It does not replace the native Windows title-bar frame with Aero glass or change the 3D render engine. Some tool-specific states or viewport overlays retain their own styles. Starting FurBrush.exe directly skips the external retro stylesheet.

APP NAME AND HELP
The native executable patch uses FurBrush in the main title and hides the Help menu action. Other internal Sisir strings and file/settings identifiers remain. Original source notices and licenses are preserved.

DIALOG ICON
Both embedded Qt application logo resources have been replaced with versions of your supplied picture, in addition to the Windows executable icon. This addresses the application icon inherited by dialogs such as save/discard. Standard warning/question symbols inside message boxes are unchanged. The actual Windows exit prompt has not been tested.

VALIDATION
The native helper passed 14 emulator cases, including relocation and lookup failures. Original executable section contents were checked against precisely declared instruction, theme and icon patches. Both embedded icons decoded in Qt. A representative Qt 6.12 Linux offscreen preview loaded Geist Pixel and rendered the QSS without stylesheet/property errors; a Qt save/discard test dialog inherited the app icon. Windows application startup, actual UI appearance and its exit dialog remain unverified.

REVERT
Close FurBrush and launch original Sisir.exe. Original application files and Windows settings have not been patched. Optional font installation is a user action. Optional paw-pointer installation affects Windows globally; see cursors/README.txt.

The splash needs Windows PowerShell 5.1 and WPF and respects execution policy. Its loading bar indicates activity rather than measured progress. This package is an overlay, not a complete standalone installation.

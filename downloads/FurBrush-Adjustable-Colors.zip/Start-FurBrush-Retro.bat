@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0FurBrush.exe" -style Fusion -stylesheet "%~dp0themes\Windows7-Retro.qss"

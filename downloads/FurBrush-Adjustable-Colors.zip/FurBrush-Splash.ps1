# Windows PowerShell 5.1 / WPF. Starts FurBrush without changing its code.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName @('PresentationFramework', 'PresentationCore', 'WindowsBase')
# Window caption override; internal labels and menus are unchanged.
Add-Type @'
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
public static class FurBrushWindowCaption {
    private delegate bool EnumWindowProc(IntPtr window, IntPtr parameter);
    [DllImport("user32.dll")]
    private static extern bool EnumWindows(EnumWindowProc callback, IntPtr parameter);
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr window, out uint processId);
    [DllImport("user32.dll")]
    private static extern bool IsWindowVisible(IntPtr window);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr window, StringBuilder text, int maximum);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr SendMessageTimeout(IntPtr window, uint message,
        UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);

    // Returns how many visible titled windows belong to this exact process.
    public static int Update(int processId) {
        int found = 0;
        EnumWindows(delegate(IntPtr window, IntPtr parameter) {
            uint owner;
            GetWindowThreadProcessId(window, out owner);
            if (owner != (uint)processId || !IsWindowVisible(window)) return true;
            StringBuilder text = new StringBuilder(4096);
            if (GetWindowText(window, text, text.Capacity) == 0) return true;
            string caption = text.ToString();
            // Exclude console/helper windows; include already-renamed windows.
            if (!Regex.IsMatch(caption, @"\b(Sisir|FurBrush)\b", RegexOptions.IgnoreCase)) return true;
            found++;
            string renamed = Regex.Replace(caption, @"\bSisir\b", "FurBrush", RegexOptions.IgnoreCase);
            if (renamed != caption) {
                UIntPtr result;
                SendMessageTimeout(window, 0x000C, UIntPtr.Zero, renamed, 0x0002, 250, out result);
            }
            return true;
        }, IntPtr.Zero);
        return found;
    }
}
'@
$exePath = Join-Path $PSScriptRoot 'FurBrush.exe'
$artPath = Join-Path $PSScriptRoot 'FurBrush-Splash.png'
if (-not (Test-Path -LiteralPath $exePath)) {
    [System.Windows.MessageBox]::Show('Place this launcher next to FurBrush.exe in your complete Sisir installation.', 'FurBrush') | Out-Null
    exit 1
}

[xml]$layout = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="FurBrush - Starting" Width="860" Height="486"
        WindowStartupLocation="CenterScreen" WindowStyle="None"
        ResizeMode="NoResize" Background="#10151E" Foreground="#FFFFFF"
        FontFamily="Segoe UI" ShowInTaskbar="True">
  <Border BorderBrush="#354158" BorderThickness="1">
    <Grid>
      <Image x:Name="Artwork" Stretch="Uniform"/>
      <Border IsHitTestVisible="False">
        <Border.Background>
          <LinearGradientBrush StartPoint="0,0" EndPoint="0,1">
            <GradientStop Color="#00000000" Offset="0.35"/>
            <GradientStop Color="#A610151E" Offset="0.65"/>
            <GradientStop Color="#F510151E" Offset="1"/>
          </LinearGradientBrush>
        </Border.Background>
      </Border>
      <StackPanel VerticalAlignment="Bottom" Margin="30,0,30,26">
        <TextBlock Text="FurBrush" FontSize="46" FontWeight="SemiBold"/>
        <TextBlock Text="Make every strand your own." Margin="2,2,0,18" FontSize="14" Foreground="#DAE5F3"/>
        <TextBlock x:Name="Status" Text="Starting application..." Foreground="#E2E8F0" FontSize="12" Margin="0,0,0,10" TextWrapping="Wrap"/>
        <ProgressBar Height="3" IsIndeterminate="True" Foreground="#65DCC4" Background="#293449" BorderThickness="0"/>
        <TextBlock Text="Launcher activity - not measured loading progress" FontSize="10" Foreground="#B2BED0" Margin="0,8,0,0"/>
      </StackPanel>
      <Button x:Name="HideButton" Content="Hide" HorizontalAlignment="Right" VerticalAlignment="Top" Margin="0,10,10,0" Padding="9,4" Background="#D0202A3B" Foreground="White" BorderBrush="#43516A" ToolTip="Hide this splash; FurBrush keeps running"/>
    </Grid>
  </Border>
</Window>
'@
$reader = New-Object System.Xml.XmlNodeReader $layout
$window = [Windows.Markup.XamlReader]::Load($reader)
$status = $window.FindName('Status')
if (Test-Path -LiteralPath $artPath) {
    $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
    $bitmap.BeginInit()
    $bitmap.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $bitmap.UriSource = [Uri]::new($artPath, [UriKind]::Absolute)
    $bitmap.EndInit()
    $window.FindName('Artwork').Source = $bitmap
}
$iconPath = Join-Path $PSScriptRoot 'FurBrush.ico'
if (Test-Path -LiteralPath $iconPath) {
    $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]::new($iconPath, [UriKind]::Absolute))
}
$state = @{ Process = $null; Clock = [Diagnostics.Stopwatch]::new(); Started = $false }
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(150)
$window.FindName('HideButton').Add_Click({ $window.Close() })
$window.Add_MouseLeftButtonDown({ $window.DragMove() })
$window.Add_ContentRendered({
    if ($state.Started) { return }
    $state.Started = $true
    try {
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = $exePath
        $startInfo.WorkingDirectory = $PSScriptRoot
        $startInfo.UseShellExecute = $false
        $themePath = Join-Path $PSScriptRoot 'themes\Windows7-Retro.qss'
        if (Test-Path -LiteralPath $themePath) {
            $startInfo.Arguments = '-style Fusion -stylesheet "' + $themePath + '"'
        }
        # Reuse an already-open copy from this installation. Starting another
        # copy can otherwise hand off to an older process we were not watching.
        foreach ($candidate in @([Diagnostics.Process]::GetProcessesByName('FurBrush'))) {
            try {
                $candidatePath = $candidate.MainModule.FileName
                if ([string]::Equals([IO.Path]::GetDirectoryName($candidatePath), $PSScriptRoot, [StringComparison]::OrdinalIgnoreCase)) {
                    if ($null -eq $state.Process) { $state.Process = $candidate }
                    else { $candidate.Dispose() }
                } else { $candidate.Dispose() }
            } catch { $candidate.Dispose() }
        }
        if ($null -eq $state.Process) {
            $state.Process = [Diagnostics.Process]::Start($startInfo)
        }
        $state.Clock.Start()
        $timer.Start()
    } catch {
        [System.Windows.MessageBox]::Show("Unable to start FurBrush:`n$($_.Exception.Message)", 'FurBrush') | Out-Null
        $window.Close()
    }
})
$timer.Add_Tick({
    try {
        $state.Process.Refresh()
        if ($state.Process.HasExited) {
            $timer.Stop()
            if ($state.Process.ExitCode -ne 0) {
                [System.Windows.MessageBox]::Show("FurBrush exited during startup (code $($state.Process.ExitCode)). Make sure you copied these files into your complete Sisir installation with all its DLLs.", 'FurBrush') | Out-Null
            }
            $window.Close()
        } elseif ($state.Clock.Elapsed.TotalSeconds -ge 1.8 -and [FurBrushWindowCaption]::Update($state.Process.Id) -gt 0) {
            $window.Close()
        } elseif ($state.Clock.Elapsed.TotalSeconds -ge 60) {
            $status.Text = 'Still starting... Use Hide to dismiss this splash.'
        }
    } catch {
        $timer.Stop()
        [System.Windows.MessageBox]::Show("The launcher could not check startup status. FurBrush may still be running.`n$($_.Exception.Message)", 'FurBrush') | Out-Null
        $window.Close()
    }
})
$window.Add_Closed({ $timer.Stop() })
$window.ShowDialog() | Out-Null
if ($null -ne $state.Process) { $state.Process.Dispose() }

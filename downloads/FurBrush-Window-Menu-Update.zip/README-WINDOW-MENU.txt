FurBrush Window menu and Info update

INSTALL
Save your scene and close FurBrush. Extract FurBrush.exe into the existing installation, replacing the previous FurBrush.exe. Keep original Sisir.exe as backup. Open FurBrush.exe.

WINDOW MENU
The visible menu order is File, Window, Edit, View, Modules, Info. Window provides checkable entries for the existing Inspector, Layers, Hair Sets and Viewport docks. Check an entry to show the panel; uncheck to hide it. These are visibility controls, not plugin loading or destructive deletion. Existing module-specific visibility behavior remains.

To restore background/HDR/lighting controls in Render, use Window > Viewport. The earlier View > Viewport and Default Layout show/raise recovery remain available. Your renderer still builds the existing controls.

INFO
Info > About opens the application's existing About dialog, now titled About FurBrush and showing FurBrush version, its Sisir basis and the original Sisir Project copyright. Existing model attribution remains. The old Help menu remains hidden. No custom Info text was supplied, so version and credits are the default.

SAVED SETTINGS
No color files, themes, scenes, fonts or preferences are included in this patch ZIP, so extracting it will not overwrite those files. The native saved-theme loader and app/dialog icon replacements are retained.

VALIDATION
24 Window/Info helper emulator cases plus 50 existing dock/theme/title helper cases passed. Qt widget testing verified visible menu order, four real dock-toggle checkbox states through show/hide/close/reopen, and reusing an existing About action/callback under Info. Independent PE structure/declared-patch checks passed. These do not run the full Windows app: confirm the new menus and panel behavior on Windows.

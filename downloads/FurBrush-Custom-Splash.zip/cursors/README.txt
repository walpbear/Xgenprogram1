OPTIONAL WINDOWS PAW POINTER

This cursor replaces the Normal Select pointer ACROSS WINDOWS, not just in FurBrush. The launcher does not install it or change Windows settings automatically.

1. Copy FurBrush-Paw.cur to a permanent location (keep this folder).
2. Open Windows Settings > Bluetooth & devices > Mouse > Additional mouse settings.
   On Windows 10: Settings > Devices > Mouse > Additional mouse options.
3. Open the Pointers tab.
4. Select Normal Select, choose Browse, and open FurBrush-Paw.cur.
5. Choose Apply. You can save the pointer scheme with Save As.

To undo: select Normal Select, choose Use Default, then Apply.

The click point is the top of the upper-left central toe at (13, 2).
FurBrush may show its own tool cursor over the grooming viewport; this Windows pointer does not change brush previews or other application-defined cursors.

# Windows PowerShell 5.1 / WPF. Starts FurBrush without changing its code.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName @('PresentationFramework', 'PresentationCore', 'WindowsBase')
# Only a window caption override; internal labels and menus are unchanged.
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class FurBrushWindowCaption {
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg,
        UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);
}
'@
$exePath = Join-Path $PSScriptRoot 'FurBrush.exe'
$artPath = Join-Path $PSScriptRoot 'FurBrush-Splash.png'
if (-not (Test-Path -LiteralPath $exePath)) {
    [System.Windows.MessageBox]::Show('Place this launcher next to FurBrush.exe in your complete Sisir installation.', 'FurBrush') | Out-Null
    exit 1
}

[xml]$layout = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="FurBrush - Starting" Width="860" Height="486"
        WindowStartupLocation="CenterScreen" WindowStyle="None"
        ResizeMode="NoResize" Background="#10151E" Foreground="#FFFFFF"
        FontFamily="Segoe UI" ShowInTaskbar="True">
  <Border BorderBrush="#354158" BorderThickness="1">
    <Grid>
      <Image x:Name="Artwork" Stretch="Uniform"/>
      <Border IsHitTestVisible="False">
        <Border.Background>
          <LinearGradientBrush StartPoint="0,0" EndPoint="0,1">
            <GradientStop Color="#00000000" Offset="0.35"/>
            <GradientStop Color="#A610151E" Offset="0.65"/>
            <GradientStop Color="#F510151E" Offset="1"/>
          </LinearGradientBrush>
        </Border.Background>
      </Border>
      <StackPanel VerticalAlignment="Bottom" Margin="30,0,30,26">
        <TextBlock Text="FurBrush" FontSize="46" FontWeight="SemiBold"/>
        <TextBlock Text="Make every strand your own." Margin="2,2,0,18" FontSize="14" Foreground="#DAE5F3"/>
        <TextBlock x:Name="Status" Text="Starting application..." Foreground="#E2E8F0" FontSize="12" Margin="0,0,0,10" TextWrapping="Wrap"/>
        <ProgressBar Height="3" IsIndeterminate="True" Foreground="#65DCC4" Background="#293449" BorderThickness="0"/>
        <TextBlock Text="Launcher activity - not measured loading progress" FontSize="10" Foreground="#B2BED0" Margin="0,8,0,0"/>
      </StackPanel>
      <Button x:Name="HideButton" Content="Hide" HorizontalAlignment="Right" VerticalAlignment="Top" Margin="0,10,10,0" Padding="9,4" Background="#D0202A3B" Foreground="White" BorderBrush="#43516A" ToolTip="Hide this splash; FurBrush keeps running"/>
    </Grid>
  </Border>
</Window>
'@
$reader = New-Object System.Xml.XmlNodeReader $layout
$window = [Windows.Markup.XamlReader]::Load($reader)
$status = $window.FindName('Status')
if (Test-Path -LiteralPath $artPath) {
    $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
    $bitmap.BeginInit()
    $bitmap.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $bitmap.UriSource = [Uri]::new($artPath, [UriKind]::Absolute)
    $bitmap.EndInit()
    $window.FindName('Artwork').Source = $bitmap
}
$iconPath = Join-Path $PSScriptRoot 'FurBrush.ico'
if (Test-Path -LiteralPath $iconPath) {
    $window.Icon = [System.Windows.Media.Imaging.BitmapFrame]::Create([Uri]::new($iconPath, [UriKind]::Absolute))
}
$state = @{ Process = $null; Clock = [Diagnostics.Stopwatch]::new(); Started = $false }
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(150)
$window.FindName('HideButton').Add_Click({ $window.Close() })
$window.Add_MouseLeftButtonDown({ $window.DragMove() })
$window.Add_ContentRendered({
    if ($state.Started) { return }
    $state.Started = $true
    try {
        $startInfo = New-Object System.Diagnostics.ProcessStartInfo
        $startInfo.FileName = $exePath
        $startInfo.WorkingDirectory = $PSScriptRoot
        $startInfo.UseShellExecute = $false
        $state.Process = [Diagnostics.Process]::Start($startInfo)
        $state.Clock.Start()
        $timer.Start()
    } catch {
        [System.Windows.MessageBox]::Show("Unable to start FurBrush:`n$($_.Exception.Message)", 'FurBrush') | Out-Null
        $window.Close()
    }
})
$timer.Add_Tick({
    try {
        $state.Process.Refresh()
        if ($state.Process.HasExited) {
            $timer.Stop()
            if ($state.Process.ExitCode -ne 0) {
                [System.Windows.MessageBox]::Show("FurBrush exited during startup (code $($state.Process.ExitCode)). Make sure you copied these files into your complete Sisir installation with all its DLLs.", 'FurBrush') | Out-Null
            }
            $window.Close()
        } elseif ($state.Process.MainWindowHandle -ne [IntPtr]::Zero -and $state.Clock.Elapsed.TotalSeconds -ge 1.8) {
            # WM_SETTEXT affects only the visible caption, not stored app data.
            $oldTitle = $state.Process.MainWindowTitle
            if ($oldTitle -match 'Sisir') {
                $newTitle = $oldTitle -replace 'Sisir', 'FurBrush'
                $captionResult = [UIntPtr]::Zero
                $sent = [FurBrushWindowCaption]::SendMessageTimeout(
                    $state.Process.MainWindowHandle, 0x000C, [UIntPtr]::Zero,
                    $newTitle, 0x0002, 500, [ref]$captionResult)
                # The application may later replace this caption itself.
            }
            $window.Close()
        } elseif ($state.Clock.Elapsed.TotalSeconds -ge 60) {
            $status.Text = 'Still starting... Use Hide to dismiss this splash.'
        }
    } catch {
        $timer.Stop()
        [System.Windows.MessageBox]::Show("The launcher could not check startup status. FurBrush may still be running.`n$($_.Exception.Message)", 'FurBrush') | Out-Null
        $window.Close()
    }
})
$window.Add_Closed({ $timer.Stop() })
$window.ShowDialog() | Out-Null
if ($null -ne $state.Process) { $state.Process.Dispose() }

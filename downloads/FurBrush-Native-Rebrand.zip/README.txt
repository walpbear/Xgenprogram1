FurBrush - EXPERIMENTAL native title and hidden Help menu

INSTALL
1. Close every running Sisir/FurBrush window and old launcher.
2. Extract this package into your COMPLETE original Sisir installation, next to Sisir.exe and all supporting DLLs. Replace the previous FurBrush files.
3. Double-click FurBrush.exe to test the native title and Help-menu patch directly.
4. For the artwork splash, use Start-FurBrush.bat instead.

Keep Sisir.exe unchanged as your original backup. This is an overlay, not a standalone installation.

CHANGES
The executable now builds its main title with 'FurBrush v' instead of 'Sisir v'. Version, filename and unsaved-change marker are preserved. A targeted helper hides the Help menu action while leaving its internal initialization intact. Icon and custom splash artwork are included.

OTHER SISIR NAMES
Internal dialogs, scene/settings identifiers, file associations and original notices may still contain Sisir. This patch targets the main title and Help menu only. It is not a full rebrand.

VALIDATION
Ghidra decompilation confirmed the patched code paths. PE structure and unchanged original code except two instruction sites were checked. The helper passed 14 emulated cases, including relocated code and failed lookups. This is NOT Windows runtime or visual validation. If Qt method lookup fails, Help remains visible rather than crashing. Real app behavior, rendering and exception handling still need Windows testing.

SPLASH
Start-FurBrush.bat shows your artwork, then closes the splash when a titled app window appears. The animated bar shows activity, not actual loading progress. Windows PowerShell 5.1/WPF is required for the optional splash; execution policy is respected.

CURSOR
Optional cursors/FurBrush-Paw.cur is a Windows Normal Select pointer. See cursors/README.txt to apply or undo it. It affects Windows globally and does not change the grooming brush cursor. No cursor settings are changed automatically.

TO REVERT
Close FurBrush and launch the untouched original Sisir.exe. No registry or app data changes are made by this patch.

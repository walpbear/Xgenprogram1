FurBrush saved-color loader fix

Close every FurBrush window. Extract FurBrush.exe into the SAME installation folder that contains Customize-Colors.bat and your themes folder. Replace the existing FurBrush.exe. Open FurBrush.exe directly.

This update deliberately contains no QSS, template or colors.json, so your saved colors are not overwritten. The patched executable now reads themes/Windows7-Retro.qss next to itself and applies it at the existing local stylesheet setter. It does not depend on launch arguments to load your colors. Keep the themes folder and its PNG assets in place.

The original Sisir.exe remains your fallback. If the QSS file cannot be opened or is empty/over 64 KiB, the original application style is used. Use Customize-Colors.bat to save a theme before restarting. Settings inside colors.json are rendered by the color editor; the application reads the resulting QSS.

Validation: 20 emulator cases tested file content application, executable-relative paths with spaces/Unicode, relocation, failure fallback and resource cleanup. The existing title/Help helper passed 14 cases. Qt testing confirmed a local Mint stylesheet replaces the original dark/purple style on representative widgets. This does not constitute running the complete Windows application; its result still needs Windows verification.

Executable SHA256: 21945dede0a1cfe6d46db3dba2df0d93ab11d77639d0c4222d156a66f452738b
